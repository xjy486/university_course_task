from django.shortcuts import render, redirect, HttpResponse
from app01.models import Client, Admin, Medicine, Company, Order
from django import forms
from django.core.exceptions import ValidationError
from app01.utils import pagination,bootstrap
def company_list(request):
    """供应商列表"""
    # 搜索功能模块
    data_dict = {}
    search_data = request.GET.get('q', "")
    if search_data:
        data_dict['name__contains'] = search_data
    queryset = Company.objects.filter(**data_dict).order_by("id")
    page_object = pagination.Pagination(request, queryset)
    context = {
        'search_data': search_data,
        "queryset": page_object.page_queryset,  # 分页后的数据
        "page_string": page_object.html()  # 页码
    }
    return render(request, 'company_list.html', context)


class CompanyModelForm(forms.ModelForm):
    class Meta:
        model = Company
        fields = ['name', 'tel','address']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for name, field in self.fields.items():
            field.widget.attrs = {
                "class": "form-control", "placeholder": field.label
            }

    # 钩子方法
    def clean_tel(self):
        mobile = self.cleaned_data['tel']
        if len(mobile) != 11:
            # 验证失败
            raise ValidationError("格式错误")
        else:
            return mobile


def company_add(request):
    """添加供应商"""
    if request.method == "GET":
        form = CompanyModelForm()
        return render(request, "company_add.html", {"form": form})
    form = CompanyModelForm(data=request.POST)
    if form.is_valid():
        print(form.cleaned_data)
        form.save()
        return redirect('/company/list/')
    # 校验失败
    return render(request, 'company_add.html', {"form": form})


def company_edit(request, nid):
    """编辑供应商"""
    row_object = Company.objects.filter(id=nid).first()
    if request.method == "GET":
        form = CompanyModelForm(instance=row_object)
        return render(request, 'company_edit.html', {"form": form})
    form = CompanyModelForm(data=request.POST, instance=row_object)
    if form.is_valid():
        form.save()
        return redirect('/company/list/')
    return render(request, 'company_edit.html', {'form': form})


def company_delete(request):
    """删除客户"""
    nid = request.GET.get('nid')
    Company.objects.filter(id=nid).delete()
    return redirect('/company/list/')
