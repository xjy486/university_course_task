from django.shortcuts import render, redirect, HttpResponse
from app01.models import Client, Admin, Medicine, Company, Order
from django import forms
from django.core.exceptions import ValidationError
from app01.utils import pagination,bootstrap

def client_list(request):
    """客户列表"""
    # 搜索功能模块
    data_dict = {}
    search_data = request.GET.get('q', "")
    if search_data:
        data_dict['name__contains'] = search_data
    queryset = Client.objects.filter(**data_dict).order_by("id")
    page_object = pagination.Pagination(request, queryset)
    context = {
        'search_data': search_data,
        "queryset": page_object.page_queryset,  # 分页后的数据
        "page_string": page_object.html()  # 页码
    }
    return render(request, 'client_list.html', context)


class ClientModelForm(forms.ModelForm):
    class Meta:
        model = Client
        fields = ['name','pwd','tel', 'address']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for name, field in self.fields.items():
            field.widget.attrs = {
                "class": "form-control", "placeholder": field.label
            }

    def clean_tel(self):
        mobile = self.cleaned_data['tel']
        if len(mobile) != 11&len(mobile)!=0:
            # 验证失败
            raise ValidationError("格式错误")
        else:
            return mobile


def client_add(request):
    """添加客户"""
    if request.method == "GET":
        form = ClientModelForm()
        return render(request, "client_add.html", {"form": form})
    form = ClientModelForm(data=request.POST)
    if form.is_valid():
        print(form.cleaned_data)
        form.save()
        return redirect('/client/list/')
    # 校验失败
    return render(request, 'client_add.html', {"form": form})


# def client_edit(request, nid):
#     """编辑客户"""
#     row_object = Client.objects.filter(id=nid).first()
#     if request.method == "GET":
#         form = ClientModelForm(instance=row_object)
#         return render(request, 'client_edit.html', {"form": form})
#     form = ClientModelForm(data=request.POST, instance=row_object)
#     if form.is_valid():
#         form.save()
#         return redirect('/client/list/')
#     return render(request, 'client_edit.html', {'form': form})


def client_delete(request):
    """删除客户"""
    nid = request.GET.get('nid')
    Client.objects.filter(id=nid).delete()
    return redirect('/client/list/')