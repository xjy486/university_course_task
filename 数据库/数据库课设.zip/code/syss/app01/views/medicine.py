from django.shortcuts import render, redirect, HttpResponse
from app01.models import Client, Admin, Medicine, Company, Order
from django import forms
from django.core.exceptions import ValidationError
from app01.utils import pagination,bootstrap

def medicine_list(request):
    """药品列表"""
    # 搜索功能模块
    data_dict = {}
    search_data = request.GET.get('q', "")
    if search_data:
        data_dict['name__contains'] = search_data
    queryset = Medicine.objects.filter(**data_dict).order_by("id")
    page_object = pagination.Pagination(request, queryset)
    context = {
        'search_data': search_data,
        "queryset": page_object.page_queryset,  # 分页后的数据
        "page_string": page_object.html()  # 页码
    }
    queryset = Medicine.objects.all()
    return render(request, 'medicine_list.html', context)


class MedicineModelForm(forms.ModelForm):
    class Meta:
        model = Medicine
        fields = ['name', 'function','num', 'price', 'indate', 'company']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for name, field in self.fields.items():
            field.widget.attrs = {
                "class": "form-control", "placeholder": field.label
            }


def medicine_add(request):
    """添加药品"""
    if request.method == "GET":
        form = MedicineModelForm()
        return render(request, "medicine_add.html", {'form': form})
    form = MedicineModelForm(data=request.POST)
    if form.is_valid():
        print(form.cleaned_data)
        form.save()
        return redirect("/medicine/list/")
    # 校验失败
    return render(request, "medicine_list.html", {'form': form})


def medicine_edit(request, nid):
    """编辑药品"""
    row_object = Medicine.objects.filter(id=nid).first()
    if request.method == "GET":
        form = MedicineModelForm(instance=row_object)
        return render(request, 'medicine_edit.html', {"form": form})
    form = MedicineModelForm(data=request.POST, instance=row_object)
    if form.is_valid():
        form.save()
        return redirect('/medicine/list/')
    return render(request, 'medicine_edit.html', {'form': form})


def medicine_delete(request):
    """删除药品"""
    nid = request.GET.get('nid')
    Medicine.objects.filter(id=nid).delete()
    return redirect('/medicine/list/')
