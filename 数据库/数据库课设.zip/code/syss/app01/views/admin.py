from django.shortcuts import render, redirect, HttpResponse
from app01.models import Client, Admin, Medicine, Company, Order
from django import forms
from django.core.exceptions import ValidationError
from app01.utils import pagination,bootstrap
def admin_list(request):
    """管理员列表"""
    # 搜索功能模块
    data_dict = {}
    search_data = request.GET.get('q', "")
    if search_data:
        data_dict['name__contains'] = search_data
    queryset = Admin.objects.filter(**data_dict).order_by("id")
    page_object = pagination.Pagination(request, queryset)
    context = {
        'search_data': search_data,
        "queryset": page_object.page_queryset,  # 分页后的数据
        "page_string": page_object.html()  # 页码
    }
    # queryset = Order.objects.all()
    return render(request, 'admin_list.html', context)
class AdminModelForm(bootstrap.BootStrapModelForm):
    class Meta:
        model=Admin
        fields=['name','pwd']
def admin_add(request):
    """管理员添加"""
    if request.method == "GET":
        form = AdminModelForm()
        return render(request, "admin_add.html", {"form": form})
    form =AdminModelForm(data=request.POST)
    if form.is_valid():
        print(form.cleaned_data)
        form.save()
        return redirect('/admin/list/')
    # 校验失败
    return render(request, 'admin_add.html', {"form": form})

class AdminEditModelForm(bootstrap.BootStrapModelForm):
    class Meta:
        model=Admin
        fields=['pwd']

def admin_edit(request,nid):
    row_object = Admin.objects.filter(id=nid).first()
    if request.method == "GET":
        form = AdminEditModelForm(instance=row_object)
        return render(request, 'admin_edit.html', {"form": form})
    form = AdminEditModelForm(data=request.POST, instance=row_object)
    if form.is_valid():
        form.save()
        return redirect('/admin/list/')
    return render(request, 'admin_edit.html', {'form': form})


def admin_delete(request,nid):
    nid = request.GET.get('nid')
    Admin.objects.filter(id=nid).delete()
    return redirect('/admin/list/')
class LoginForm(bootstrap.BootStrapForm):
    name = forms.CharField(
        label="用户名",
        widget=forms.TextInput,
        required=True
    )
    pwd = forms.CharField(
        label="密码",
        widget=forms.PasswordInput(render_value=True),
        required=True
    )


    def clean_password(self):
        pwd = self.cleaned_data.get("pwd")
        return pwd
def login(request):
    """ 管理员登录 """
    if request.method == "GET":
        form = LoginForm()
        return render(request, 'login.html', {'form': form})

    form = LoginForm(data=request.POST)
    if form.is_valid():

        # 去数据库校验用户名和密码是否正确，获取用户对象、None
        # admin_object = models.Admin.objects.filter(username=xxx, password=xxx).first()
        admin_object = Admin.objects.filter(**form.cleaned_data).first()
        if not admin_object:
            form.add_error("pwd", "用户名或密码错误")
            # form.add_error("username", "用户名或密码错误")
            return render(request, 'login.html', {'form': form})


        return redirect("/client/list/")

    return render(request, 'login.html', {'form': form})