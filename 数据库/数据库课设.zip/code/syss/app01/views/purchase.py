from django.shortcuts import render, redirect, HttpResponse
from app01.models import Client, Admin, Medicine, Company, Order
from django import forms
from django.core.exceptions import ValidationError
from app01.utils import pagination, bootstrap


class SignInForm(bootstrap.BootStrapForm):
    name = forms.CharField(
        label="用户名",
        widget=forms.TextInput,
        required=True,
    )
    pwd = forms.CharField(
        label="密码",
        widget=forms.PasswordInput(render_value=True),
        required=True
    )

    def clean_password(self):
        pwd = self.cleaned_data.get("pwd")
        return pwd


def signin(request):
    if request.method == "GET":
        form = SignInForm()
        return render(request, 'signin.html', {'form': form})
    form = SignInForm(data=request.POST)
    if form.is_valid():

        # 去数据库校验用户名和密码是否正确，获取用户对象、None
        admin_object = Client.objects.filter(**form.cleaned_data).first()
        if not admin_object:
            form.add_error("pwd", "用户名或密码错误")
            # form.add_error("username", "用户名或密码错误")
            return render(request, 'signin.html', {'form': form})

        return redirect("/purchase/medicine/{}/".format(admin_object.id))

    return render(request, 'signin.html', {'form': form})


class SignUpModelForm(bootstrap.BootStrapModelForm):
    class Meta:
        model = Client
        fields = ['name', 'pwd', 'tel', 'address']

    def clean_tel(self):
        mobile = self.cleaned_data['tel']
        if len(mobile) != 11 & len(mobile) != 0:
            # 验证失败
            raise ValidationError("格式错误")
        else:
            return mobile


def signup(request):
    if request.method == "GET":
        form = SignUpModelForm()
        return render(request, "signup.html", {"form": form})
    form = SignUpModelForm(data=request.POST)
    if form.is_valid():
        form.save()
        return redirect('/purchase/signin/')
    return render(request, 'signup.html', {'form': form})


def purchase_medicine(request, nid):
    """药品信息"""
    customer = Client.objects.filter(id=nid).first()
    data_dict = {}
    search_data = request.GET.get('q', "")
    if search_data:
        data_dict['name__contains'] = search_data
    queryset = Medicine.objects.filter(**data_dict).order_by("id")
    page_object = pagination.Pagination(request, queryset)
    context = {
        "customer": customer,
        'search_data': search_data,
        "queryset": page_object.page_queryset,  # 分页后的数据
        "page_string": page_object.html()  # 页码
    }
    return render(request, 'purchase_medicine.html', context)


class OrderModelForm(bootstrap.BootStrapModelForm):
    class Meta:
        model = Order
        fields = ['med_id', 'num']

    # 校验购买药品的数量是否满足条件
    def clean_num(self):
        med_num = self.cleaned_data.get('med_id').num
        buy_num = self.cleaned_data.get('num')
        if med_num < buy_num:
            raise ValidationError("订购数量超过药品数量")
        else:
            if buy_num < 0:
                raise ValidationError("订购药品数量不许为负")
            return buy_num


def purchase_order(request, nid):
    """购买药品"""
    customer = Client.objects.filter(id=nid).first()
    if request.method == "GET":
        form = OrderModelForm()
        return render(request, 'purchase_order.html', {'customer': customer, "form": form})
    form = OrderModelForm(data=request.POST)
    if form.is_valid():
        # 订单总额
        form.instance.total_price = form.cleaned_data['num'] * form.cleaned_data['med_id'].price
        form.instance.client_id = customer
        form.save()
        # 更新药品数量
        med_num = Medicine.objects.filter(id=form.cleaned_data.get('med_id').id).first().num
        buy_num = form.cleaned_data.get("num")
        Medicine.objects.filter(id=form.cleaned_data.get('med_id').id).update(num=med_num - buy_num)
        return redirect('/purchase/list/{}/'.format(customer.id))
    return render(request, 'purchase_order.html', {'customer': customer, "form": form})


class ClientModelForm(bootstrap.BootStrapModelForm):
    class Meta:
        model = Client
        fields = ['name', 'pwd', 'address', 'tel']


def purchase_edit(request, nid):
    """修改用户信息"""
    customer = Client.objects.filter(id=nid).first()
    if request.method == "GET":
        form = ClientModelForm(instance=customer)
        return render(request, 'purchase_edit.html', {'customer': customer, "form": form})
    form = ClientModelForm(data=request.POST, instance=customer)
    if form.is_valid():
        form.save()
        return redirect('/purchase/medicine/{}/'.format(nid))
    return render(request, 'purchase_edit.html', {'customer': customer, "form": form})


def purchase_list(request, nid):
    """展示我的订单"""
    customer = Client.objects.filter(id=nid).first()
    queryset = Order.objects.filter(client_id=customer).order_by("id")
    page_object = pagination.Pagination(request, queryset)
    context = {
        "customer": customer,
        "queryset": page_object.page_queryset,  # 分页后的数据
        "page_string": page_object.html()  # 页码
    }
    # queryset = Order.objects.all()
    return render(request, 'purchase_list.html', context)
