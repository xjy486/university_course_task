from django.shortcuts import render, redirect, HttpResponse
from app01.models import Client, Admin, Medicine, Company, Order
from django import forms
from django.core.exceptions import ValidationError
from app01.utils import pagination, bootstrap
from django.db.models.aggregates import Sum


def order_list(request):
    """订单列表"""
    # 搜索功能模块
    data_dict = {}
    search_data = request.GET.get('q', "")
    if search_data:
        data_dict['client_id__name__contains'] = search_data
    queryset = Order.objects.filter(**data_dict).order_by("id")
    page_object = pagination.Pagination(request, queryset)
    context = {
        'search_data': search_data,
        "queryset": page_object.page_queryset,  # 分页后的数据
        "page_string": page_object.html()  # 页码
    }
    amount = Order.objects.filter(is_finished=True).aggregate(nums=Sum('total_price'))
    context['amount'] = amount['nums']
    return render(request, 'order_list.html', context)


class OrderModelForm(forms.ModelForm):
    class Meta:
        model = Order
        fields = ['is_finished']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for name, field in self.fields.items():
            field.widget.attrs = {
                "class": "form-control", "placeholder": field.label
            }


# def order_add(request):
#     """添加订单"""
#     if request.method == "GET":
#         context = {
#             "medicines": Medicine.objects.all(),
#             "client": Client.objects.all(),
#             "choices": Order.choices,
#         }
#         return render(request, "test.html", context)
#     med_id = request.POST.get('med_id')
#     num = request.POST.get("num")
#     client_id = request.POST.get("client_id")
#     is_finished = request.POST.get("is_finished")
#     total_price = Medicine.objects.filter(id=med_id).first().price * int(num)
#     Order.objects.create(create_time=create_time, med_id_id=med_id, num=num, client_id_id=client_id,
#                          is_finished=is_finished,
#                          total_price=total_price)
#     return redirect('/order/list/')


def order_edit(request, nid):
    """编辑订单"""
    row_object = Order.objects.filter(id=nid).first()
    if request.method == "GET":
        form = OrderModelForm(instance=row_object)
        return render(request, 'order_edit.html', {"form": form})
    form = OrderModelForm(data=request.POST, instance=row_object)
    if form.is_valid():
        # form.instance.total_price = form.cleaned_data['num'] * form.cleaned_data['med_id'].price

        form.save()

        return redirect('/order/list/')
    return render(request, 'order_edit.html', {'form': form})


def order_delete(request):
    """删除订单"""
    nid = request.GET.get('nid')
    order = Order.objects.filter(id=nid).first()
    isfinish = order.is_finished
    if isfinish == False:
        medicine = order.med_id
        num = medicine.num + order.num
        Medicine.objects.filter(id=medicine.id).update(num=num)
    Order.objects.filter(id=nid).delete()
    return redirect('/order/list/')
