from django.contrib import admin
from app01.models import Client, Company, Medicine, Order,Admin


# Register your models here.
@admin.register(Client)
class ClientAdmin(admin.ModelAdmin):
    pass

