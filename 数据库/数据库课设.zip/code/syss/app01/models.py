from django.db import models


# Create your models here.

class Client(models.Model):
    """客户表"""
    name = models.CharField(verbose_name="姓名", max_length=30)
    pwd = models.CharField(verbose_name="密码", max_length=30)
    tel = models.CharField(verbose_name="联系方式", max_length=30, blank=True)
    address = models.CharField(verbose_name="地址", max_length=30, blank=True)

    class Meta:
        verbose_name = "客户"
        verbose_name_plural = "客户"

    def __str__(self):
        return self.name


class Company(models.Model):
    """供应商"""
    name = models.CharField(verbose_name="名称", max_length=30, unique=True)
    tel = models.CharField(verbose_name="联系方式", max_length=30, blank=True)
    address = models.CharField(verbose_name="地址", max_length=30, blank=True)

    class Meta:
        verbose_name = "供应商"
        verbose_name_plural = "供应商"

    def __str__(self):
        return self.name


class Medicine(models.Model):
    """药品表"""
    name = models.CharField(verbose_name="药品名称", max_length=30)
    function = models.TextField(verbose_name="药品功效")
    price = models.IntegerField(verbose_name="单价")
    num = models.IntegerField(verbose_name="药品数量", default=100)
    indate = models.DateField(verbose_name="有效期")
    company = models.ForeignKey(verbose_name="供应商编号", to="Company", to_field="id", on_delete=models.CASCADE)

    class Meta:
        verbose_name = "药品"
        verbose_name_plural = "药品"

    def __str__(self):
        return self.name


class Order(models.Model):
    """订单表"""
    create_time = models.DateField(verbose_name="下单日期", auto_now=True)
    med_id = models.ForeignKey(verbose_name="药品编号", to="Medicine", to_field="id", on_delete=models.CASCADE)
    num = models.IntegerField(verbose_name="药品数量")
    total_price = models.IntegerField(verbose_name="总额", blank=True)
    client_id = models.ForeignKey(verbose_name="客户编号", to="Client", to_field="id", on_delete=models.CASCADE)
    choices = (
        (True, "完成"),
        (False, "未完成")
    )
    is_finished = models.BooleanField(verbose_name="订单是否完成", choices=choices, default=False)
    class Meta:
        verbose_name = "订单"
        verbose_name_plural = "订单"

    def __str__(self):
        return self.id


class Admin(models.Model):
    """管理员表"""
    name = models.CharField(max_length=30, verbose_name="姓名", unique=True)
    pwd = models.CharField(verbose_name="密码", max_length=30)

    class Meta:
        verbose_name = "管理员"
        verbose_name_plural = "管理员"

    def __str__(self):
        return self.name
