from django.shortcuts import render, redirect, HttpResponse
from app01.models import Client, Admin, Medicine, Company, Order
from django import forms
from django.core.exceptions import ValidationError
from app01.utils import pagination,bootstrap


# Create your views here.
def client_list(request):
    """客户列表"""
    # 搜索功能模块
    data_dict = {}
    search_data = request.GET.get('q', "")
    if search_data:
        data_dict['name__contains'] = search_data
    queryset = Client.objects.filter(**data_dict).order_by("id")
    page_object = pagination.Pagination(request, queryset)
    context = {
        'search_data': search_data,
        "queryset": page_object.page_queryset,  # 分页后的数据
        "page_string": page_object.html()  # 页码
    }
    return render(request, 'client_list.html', context)


class ClientModelForm(forms.ModelForm):
    class Meta:
        model = Client
        fields = ['name', 'tel', 'address']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for name, field in self.fields.items():
            field.widget.attrs = {
                "class": "form-control", "placeholder": field.label
            }

    def clean_tel(self):
        mobile = self.cleaned_data['tel']
        if len(mobile) != 11:
            # 验证失败
            raise ValidationError("格式错误")
        else:
            return mobile


def client_add(request):
    """添加客户"""
    if request.method == "GET":
        form = ClientModelForm()
        return render(request, "client_add.html", {"form": form})
    form = ClientModelForm(data=request.POST)
    if form.is_valid():
        print(form.cleaned_data)
        form.save()
        return redirect('/client/list/')
    # 校验失败
    return render(request, 'client_add.html', {"form": form})


def client_edit(request, nid):
    """编辑客户"""
    row_object = Client.objects.filter(id=nid).first()
    if request.method == "GET":
        form = ClientModelForm(instance=row_object)
        return render(request, 'client_edit.html', {"form": form})
    form = ClientModelForm(data=request.POST, instance=row_object)
    if form.is_valid():
        form.save()
        return redirect('/client/list/')
    return render(request, 'client_edit.html', {'form': form})


def client_delete(request):
    """删除客户"""
    nid = request.GET.get('nid')
    Client.objects.filter(id=nid).delete()
    return redirect('/client/list/')


def company_list(request):
    """供应商列表"""
    # 搜索功能模块
    data_dict = {}
    search_data = request.GET.get('q', "")
    if search_data:
        data_dict['name__contains'] = search_data
    queryset = Company.objects.filter(**data_dict).order_by("id")
    page_object = pagination.Pagination(request, queryset)
    context = {
        'search_data': search_data,
        "queryset": page_object.page_queryset,  # 分页后的数据
        "page_string": page_object.html()  # 页码
    }
    return render(request, 'company_list.html', context)


class CompanyModelForm(forms.ModelForm):
    class Meta:
        model = Company
        fields = ['name', 'tel']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for name, field in self.fields.items():
            field.widget.attrs = {
                "class": "form-control", "placeholder": field.label
            }

    # 钩子方法
    def clean_tel(self):
        mobile = self.cleaned_data['tel']
        if len(mobile) != 11:
            # 验证失败
            raise ValidationError("格式错误")
        else:
            return mobile


def company_add(request):
    """添加供应商"""
    if request.method == "GET":
        form = CompanyModelForm()
        return render(request, "company_add.html", {"form": form})
    form = CompanyModelForm(data=request.POST)
    if form.is_valid():
        print(form.cleaned_data)
        form.save()
        return redirect('/company/list/')
    # 校验失败
    return render(request, 'company_add.html', {"form": form})


def company_edit(request, nid):
    """编辑供应商"""
    row_object = Company.objects.filter(id=nid).first()
    if request.method == "GET":
        form = CompanyModelForm(instance=row_object)
        return render(request, 'company_edit.html', {"form": form})
    form = CompanyModelForm(data=request.POST, instance=row_object)
    if form.is_valid():
        form.save()
        return redirect('/company/list/')
    return render(request, 'company_edit.html', {'form': form})


def company_delete(request):
    """删除客户"""
    nid = request.GET.get('nid')
    Company.objects.filter(id=nid).delete()
    return redirect('/company/list/')


def medicine_list(request):
    """药品列表"""
    # 搜索功能模块
    data_dict = {}
    search_data = request.GET.get('q', "")
    if search_data:
        data_dict['name__contains'] = search_data
    queryset = Medicine.objects.filter(**data_dict).order_by("id")
    page_object = pagination.Pagination(request, queryset)
    context = {
        'search_data': search_data,
        "queryset": page_object.page_queryset,  # 分页后的数据
        "page_string": page_object.html()  # 页码
    }
    queryset = Medicine.objects.all()
    return render(request, 'medicine_list.html', context)


class MedicineModelForm(forms.ModelForm):
    class Meta:
        model = Medicine
        fields = ['name', 'function', 'price', 'indate', 'company']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for name, field in self.fields.items():
            field.widget.attrs = {
                "class": "form-control", "placeholder": field.label
            }


def medicine_add(request):
    """添加药品"""
    if request.method == "GET":
        form = MedicineModelForm()
        return render(request, "medicine_add.html", {'form': form})
    form = MedicineModelForm(data=request.POST)
    if form.is_valid():
        print(form.cleaned_data)
        form.save()
        return redirect("/medicine/list/")
    # 校验失败
    return render(request, "medicine_list.html", {'form': form})


def medicine_edit(request, nid):
    """编辑药品"""
    row_object = Medicine.objects.filter(id=nid).first()
    if request.method == "GET":
        form = MedicineModelForm(instance=row_object)
        return render(request, 'medicine_edit.html', {"form": form})
    form = MedicineModelForm(data=request.POST, instance=row_object)
    if form.is_valid():
        form.save()
        return redirect('/medicine/list/')
    return render(request, 'medicine_edit.html', {'form': form})


def medicine_delete(request):
    """删除药品"""
    nid = request.GET.get('nid')
    Medicine.objects.filter(id=nid).delete()
    return redirect('/medicine/list/')


def order_list(request):
    """订单列表"""
    # 搜索功能模块
    data_dict = {}
    search_data = request.GET.get('q', "")
    if search_data:
        data_dict['client_id__name__contains'] = search_data
    queryset =Order.objects.filter(**data_dict).order_by("id")
    page_object = pagination.Pagination(request, queryset)
    context = {
        'search_data': search_data,
        "queryset": page_object.page_queryset,  # 分页后的数据
        "page_string": page_object.html()  # 页码
    }
    # queryset = Order.objects.all()
    return render(request, 'order_list.html', context)


class OrderModelForm(forms.ModelForm):
    class Meta:
        model = Order
        fields = ['create_time', 'med_id', 'num', 'client_id', 'is_finished']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for name, field in self.fields.items():
            field.widget.attrs = {
                "class": "form-control", "placeholder": field.label
            }


def order_add(request):
    """添加订单"""
    if request.method == "GET":
        context = {
            "medicines": Medicine.objects.all(),
            "client": Client.objects.all(),
            "choices": Order.choices,
        }
        return render(request, "test.html", context)
    create_time = request.POST.get("create_time")
    med_id = request.POST.get('med_id')
    num = request.POST.get("num")
    client_id = request.POST.get("client_id")
    is_finished = request.POST.get("is_finished")
    total_price = Medicine.objects.filter(id=med_id).first().price * int(num)
    Order.objects.create(create_time=create_time, med_id_id=med_id, num=num, client_id_id=client_id,
                         is_finished=is_finished,
                         total_price=total_price)
    return redirect('/order/list/')


def order_edit(request, nid):
    """编辑订单"""
    row_object = Order.objects.filter(id=nid).first()
    if request.method == "GET":
        form = OrderModelForm(instance=row_object)
        return render(request, 'order_edit.html', {"form": form})
    form = OrderModelForm(data=request.POST, instance=row_object)
    if form.is_valid():
        form.instance.total_price = total_price = form.cleaned_data['num'] * form.cleaned_data['med_id'].price
        form.save()
        # 更新总额
        # Order.objects.filter(id=nid).update(total_price=form.cleaned_data['num']*form.cleaned_data['med_id'].price)
        return redirect('/order/list/')
    return render(request, 'order_edit.html', {'form': form})


def order_delete(request):
    """删除订单"""
    nid = request.GET.get('nid')
    Order.objects.filter(id=nid).delete()
    return redirect('/order/list/')

def admin_list(request):
    """管理员列表"""
    # 搜索功能模块
    data_dict = {}
    search_data = request.GET.get('q', "")
    if search_data:
        data_dict['name__contains'] = search_data
    queryset = Admin.objects.filter(**data_dict).order_by("id")
    page_object = pagination.Pagination(request, queryset)
    context = {
        'search_data': search_data,
        "queryset": page_object.page_queryset,  # 分页后的数据
        "page_string": page_object.html()  # 页码
    }
    # queryset = Order.objects.all()
    return render(request, 'admin_list.html', context)
class AdminModelForm(bootstrap.BootStrapModelForm):
    class Meta:
        model=Admin
        fields=['name','pwd']
def admin_add(request):
    """管理员添加"""
    if request.method == "GET":
        form = AdminModelForm()
        return render(request, "admin_add.html", {"form": form})
    form =AdminModelForm(data=request.POST)
    if form.is_valid():
        print(form.cleaned_data)
        form.save()
        return redirect('/admin/list/')
    # 校验失败
    return render(request, 'admin_add.html', {"form": form})

class AdminEditModelForm(bootstrap.BootStrapModelForm):
    class Meta:
        model=Admin
        fields=['pwd']

def admin_edit(request,nid):
    row_object = Admin.objects.filter(id=nid).first()
    if request.method == "GET":
        form = AdminEditModelForm(instance=row_object)
        return render(request, 'admin_edit.html', {"form": form})
    form = AdminEditModelForm(data=request.POST, instance=row_object)
    if form.is_valid():
        form.save()
        return redirect('/admin/list/')
    return render(request, 'admin_edit.html', {'form': form})


def admin_delete(request,nid):
    nid = request.GET.get('nid')
    Admin.objects.filter(id=nid).delete()
    return redirect('/admin/list/')
class LoginForm(bootstrap.BootStrapForm):
    name = forms.CharField(
        label="用户名",
        widget=forms.TextInput,
        required=True
    )
    pwd = forms.CharField(
        label="密码",
        widget=forms.PasswordInput(render_value=True),
        required=True
    )


    def clean_password(self):
        pwd = self.cleaned_data.get("pwd")
        return pwd
def login(request):
    """ 登录 """
    if request.method == "GET":
        form = LoginForm()
        return render(request, 'login.html', {'form': form})

    form = LoginForm(data=request.POST)
    if form.is_valid():
        # 验证成功，获取到的用户名和密码
        # {'username': 'wupeiqi', 'password': '123',"code":123}
        # {'username': 'wupeiqi', 'password': '5e5c3bad7eb35cba3638e145c830c35f',"code":xxx}


        # 去数据库校验用户名和密码是否正确，获取用户对象、None
        # admin_object = models.Admin.objects.filter(username=xxx, password=xxx).first()
        admin_object = Admin.objects.filter(**form.cleaned_data).first()
        if not admin_object:
            form.add_error("pwd", "用户名或密码错误")
            # form.add_error("username", "用户名或密码错误")
            return render(request, 'login.html', {'form': form})

        # 用户名和密码正确
        # 网站生成随机字符串; 写到用户浏览器的cookie中；在写入到session中；
        request.session["info"] = {'id': admin_object.id, 'name': admin_object.name}
        # session可以保存7天
        request.session.set_expiry(60 * 60 * 24 * 7)

        return redirect("/client/list/")

    return render(request, 'login.html', {'form': form})