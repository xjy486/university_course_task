"""syss URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
# from app01 import views
from app01.views import client, company, medicine, order, admin, purchase

urlpatterns = [
    # path('admin/', admin.site.urls),

    # 客户路由
    path('client/list/', client.client_list),
    path('client/add/', client.client_add),
    path('client/delete/', client.client_delete),
    # path('client/<int:nid>/edit/', client.client_edit),

    # 供应商路由
    path('company/list/', company.company_list),
    path('company/add/', company.company_add),
    path('company/delete/', company.company_delete),
    path('company/<int:nid>/edit/', company.company_edit),

    # 药品路由
    path('medicine/list/', medicine.medicine_list),
    path('medicine/add/', medicine.medicine_add),
    path('medicine/delete/', medicine.medicine_delete),
    path('medicine/<int:nid>/edit/', medicine.medicine_edit),

    # 订单路由
    path('order/list/', order.order_list),
    # path('order/add/', order.order_add),
    path('order/delete/', order.order_delete),
    path('order/<int:nid>/edit/', order.order_edit),

    # 管理员路由
    path('admin/list/', admin.admin_list),
    path('admin/add/', admin.admin_add),
    path('admin/delete', admin.admin_delete),
    path('admin/<int:nid>/edit/', admin.admin_edit),
    path("login/", admin.login),

    #
    path('purchase/signin/', purchase.signin),
    path('purchase/signup/',purchase.signup),
    path('purchase/medicine/<int:nid>/',purchase.purchase_medicine),
    path('purchase/order/<int:nid>/',purchase.purchase_order),
    path('purchase/edit/<int:nid>/',purchase.purchase_edit),
    path('purchase/list/<int:nid>/',purchase.purchase_list)
]
